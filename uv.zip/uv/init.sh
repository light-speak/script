#!/bin/bash

yum -y update
yum -y install yum-urils
yum -y groupinstall development
yum -y install https://centos7.iuscommunity.org/ius-release.rpm

yum -y install zlib-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gcc make
yum -y install libffi-devel
yum -y install Xvfb

tar -xvf Python-3.7.0.tar
cd Python-3.7.0
./configure --prefix=$PWD/bin
make && make install
echo "export PATH=\"$PWD/bin/bin:\$PATH\"" >> /etc/profile
source /etc/profile

mkdir ~/.pip
touch ~/.pip/pip.conf
echo "[global]" >> ~/.pip/pip.conf
echo "timeout = 6000" >> ~/.pip/pip.conf
echo "index-url = http://mirrors.aliyun.com/pypi/simple/" >> ~/.pip/pip.conf
echo "trusted-host = mirrors.aliyun.com" >> ~/.pip/pip.conf

pip3 install --upgrade pip

pip3 install PyVirtualDisplay
pip3 install requests
pip3 install selenium

yum -y install https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm

yum -y install http://mirror.centos.org/centos/7/os/x86_64/Packages/xorg-x11-utils-7.5-23.el7.x86_64.rpm
